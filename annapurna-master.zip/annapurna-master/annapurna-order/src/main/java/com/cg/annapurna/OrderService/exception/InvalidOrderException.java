package com.cg.annapurna.OrderService.exception;

public class InvalidOrderException extends Exception {

	public InvalidOrderException(String message) {
		super(message);
	}
}
