package com.cg.annapurna.OrderService.exception;


public class OrderNotFoundException extends Exception {

	public OrderNotFoundException (String message){
		super(message);
	}
}
